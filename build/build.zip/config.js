window["Config"] = {
  LayoutURL: ":20087/layout.aspx",
  ReportURL: ":20087/report.aspx",
  AttachmentURL: "http://34.233.140.188:2088/file.aspx",
  SAPSyncURL: "http://35.168.148.54:2090",
  FileDownload: "http://localhost:2090",
};
